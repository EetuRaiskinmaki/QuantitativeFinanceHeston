% =========================================================================
% MAIN SCRIPT: Heston Model Calibration & Exotic Option Pricing
% =========================================================================
% Nimetty tiedosto: Main.m
% Tarvittavat tiedostot: empVolatilitySurfaceData.mat, calibrationSettings.m,
%                        jacobianest.m, CallPricingFFT.m, CharacteristicFunctionLib.m
% Tarvittavat toolboxit: Financial toolbox ja Parallel Computing toolbox
% =========================================================================

%% --- Alustus ---
% Tyhjennetään muisti, komentorivi, suljetaan kuvaajat ja päiväkirja
clear; clc; close all; diary off;

% Käynnistä paralleli-ympäristö (jos ei ole jo käynnissä)
if isempty(gcp('nocreate'))
    parpool; % Vaati Parallel Computing Toolboxin
end

fprintf('=== Aloitetaan Heston-mallin kalibrointi ja eksoottisen option hinnoittelu ===\n');

%% --- Asetukset ---
% Ladataan kalibrointiasetukset ja markkinadata
settings = calibrationSettings(); 
load('empVolatilitySurfaceData.mat');  

% Parametrien nimet tulostusta varten
paramNames = {'κ (kappa)', 'θ (theta)', 'η (eta)', 'ρ (rho)', 'V₀'}; 

%% --- Tehtävä 1: Heston-mallin kalibrointi ---
fprintf('\n--- TEHTÄVÄ 1: Mallin kalibrointi ---\n');

% 1.1 Kootaan markkinadata helpommin käsiteltävään muotoon struct-rakenteeseen
marketData = struct('K', data.K, 'T', data.T, 'IV', data.IVolSurf,...
                   'r', data.r, 'S0', data.S0);

% 1.2 Määritellään optimointifunktio (häviöfunktio) anonyyminä funktiona
% Tämä funktio laskee eron mallin ja markkinan implisiittisten volatiliteettien välillä
lossFunc = @(params) calculateHestonLoss(params, marketData, settings);

% 1.3 Suoritetaan kalibrointi käyttäen fmincon-optimoijaa
% Etsitään parametrit, jotka minimoivat häviöfunktion arvon
[optParams, finalLoss, ~, output] = runCalibration(lossFunc, settings);

% 1.4 Lasketaan optimoitujen parametrien standardivirheet
% Käytetään jacobianest-funktiota Jacobin matriisin estimointiin
jac = jacobianest(lossFunc, optParams);
covMatrix = inv(jac'*jac);
stdErrors = sqrt(diag(covMatrix));

% 1.5 Tulostetaan tulokset
printCalibrationResults(optParams, stdErrors, finalLoss, output, paramNames);

% 1.6 Visualisoidaan markkinan implisiittinen volatiliteettipinta ja mallin tuottama kalibroitu pinta
if settings.displayProvisionalResults
    visualizeSurfaces(optParams, marketData, settings);
end

%% --- Tehtävä 2: Eksoottisen option hinnoittelu ---
fprintf('\n--- TEHTÄVÄ 2: Option hinnoittelu ---\n');

% 2.1 Määritellään eksoottisen option ja simulaation parametrit
% Käytetään Tehtävä 1:ssä kalibroituja Heston-mallin parametreja
simParams = struct(...
    'T', 1,...                  % Option maturiteetti vuosissa
    'H', 0.85,...               % Down-and-in barrier -taso
    'M', 1e5,...                % Monte Carlo -simulaatioiden määrä
    'dt', 1/252,...             % Aikastepelin pituus (päivätasolla, 252 kaupankäyntipäivää vuodessa)
    'kappa', optParams(1),...   % Kalibroitu kappa 
    'theta', optParams(2),...   % Kalibroitu theta
    'eta', optParams(3),...     % Kalibroitu eta
    'rho', optParams(4),...     % Kalibroitu rho 
    'V0', optParams(5),...      % Kalibroitu V0 
    'r', marketData.r);         % Riskitön korkokanta 

% 2.2 Suoritetaan Monte Carlo -simulaatio eksoottisen option hinnan laskemiseksi
optionPrice = priceExoticOption(marketData.S0, marketData.r, simParams); 

% 2.3 Tulostetaan eksoottisen option laskettu hinta
fprintf('\n[LOPPUTULOS] Eksoottisen option hinta: %.4f\n', optionPrice);

% =========================================================================
%% --- Apufunktiot ---
% =========================================================================
function loss = calculateHestonLoss(params, marketData, settings)
    % Laskee neliösumman erotuksista markkinan ja Heston-mallin
    % implisiittisten volatiliteettien välillä.
    % - Käyttää FFT-pohjaista hinnoittelua (CallPricingFFT) Eurooppalaisille call-optioille.
    % - Muuntaa mallin hinnat implisiittisiksi volatiliteeteiksi (blsimpv).
    % - Käsittelee mahdolliset virheet blsimpv-laskennassa NaN-arvoina.
    % - Hyödyntää rinnakkaislaskentaa (parfor) nopeuttaakseen laskentaa.
    
    modelIV = zeros(size(marketData.IV)); % Alustetaan matriisi mallin implisiittisille volatiliteeteille
    % Puretaan marketData-rakenteen kentät omiin muuttujiinsa luettavuuden parantamiseksi
    [S0, r, K, T] = deal(marketData.S0, marketData.r, marketData.K, marketData.T);
    
    parfor i = 1:numel(marketData.IV) % Rinnakkaislaskenta kaikkien optioiden yli
        [row, col] = ind2sub(size(marketData.IV), i); % Haetaan rivi- ja sarakeindeksit maturiteetille ja strikelle
        try
            % Lasketaan option hinta Heston-mallilla käyttäen FFT-menetelmää
            price = CallPricingFFT('Heston', settings.n, S0, K(col), T(row),...
                                  r, 0, params(5), params(2), params(1),...
                                  params(3), params(4));
            % Muunnetaan hinta implisiittiseksi volatiliteetiksi
            modelIV(i) = blsimpv(S0, K(col), r, T(row), max(0, price));
        catch
            modelIV(i) = NaN; % Virheiden hallinta
        end
    end
    
    valid = ~isnan(modelIV);
    loss = sum((marketData.IV(valid) - modelIV(valid)).^2);
end
% =========================================================================
function [optParams, loss, exitFlag, output] = runCalibration(lossFunc, settings)
    % Suorittaa Heston-mallin parametrien kalibroinnin käyttäen fmincon-optimoijaa.
    % - Käyttää calibrationSettings.m -tiedostossa määriteltyjä alkuarvoja ja rajoja parametreille.
    % - Mahdollistaa rinnakkaislaskennan optimoinnissa ('UseParallel', true).
    
    % Määritellään optimointialgoritmin asetukset
    optOptions = optimoptions('fmincon',...
        'MaxFunctionEvaluations', settings.calibrOptions.MaxFunEvals,...
        'MaxIterations', settings.calibrOptions.MaxIter,...
        'Display', settings.calibrOptions.Display,...
        'UseParallel', true); % Rinnakkaislaskenta päälle
    
    % fmincon-funktiokutsu:
    % lossFunc: minimoitava häviöfunktio
    % settings.parameters0: parametrien alkuarvot
    % [], [], [], []: lineaarisia tasa-arvo- tai epätasa-arvorajoitteita ei käytetä (A, b, Aeq, beq)
    % alarajat (lb): parametrien minimiarvot
    % ylärajat (ub): parametrien maksimiarvot
    % []: epälineaarisia rajoitteita (nonlcon) ei käytetä
    % optOptions: edellä määritellyt optimointiasetukset
    [optParams, loss, exitFlag, output] = fmincon(...
        lossFunc, settings.parameters0, [], [], [], [],...
        [settings.minKappa, settings.minTheta, settings.minEta,...
         settings.minRho, settings.minV0],...
        [settings.maxKappa, settings.maxTheta, settings.maxEta,...
         settings.maxRho, settings.maxV0],...
        [], optOptions);
end
% =========================================================================
function printCalibrationResults(params, stdErrors, loss, output, paramNames)
    % Tulostaa kalibroinnin tulokset selkeästi formatoituna komentoriville.
    % Sisältää estimoidut parametriarvot, niiden standardivirheet,
    % lopullisen häviöfunktion arvon ja optimoijan statistiikan.
    
    fprintf('\n=== KALIBROINTITULOKSET ===\n');
    fprintf('Parametri    Arvio      Std.Virhe\n');
    fprintf('-----------------------------\n');
    for i = 1:length(params)
        fprintf('%-12s %-9.4f ± %.4f\n', paramNames{i}, params(i), stdErrors(i));
    end
    fprintf('\nHäviöfunktion arvo: %.4f\n', loss);
    fprintf('Optimoinnin statistiikkaa:\n');
    disp(output);
end
% =========================================================================
function visualizeSurfaces(params, marketData, settings)
    % Visualisoi kaksi 3D-pintakuvaajaa:
    % 1. Markkinan implisiittinen volatiliteettipinta.
    % 2. Heston-mallilla kalibroiduilla parametreilla tuotettu implisiittinen volatiliteettipinta.
    
    modelIV = zeros(size(marketData.IV));
    % Lasketaan mallin implisiittiset volatiliteetit kaikille markkinadatan optioille    
    for i = 1:length(marketData.T) % Iteroidaan maturiteettien yli
        for j = 1:length(marketData.K)% Iteroidaan strike-hintojen yli
            % Lasketaan option hinta Heston-mallilla
            price = CallPricingFFT('Heston', settings.n, marketData.S0,...
                                  marketData.K(j), marketData.T(i),...
                                  marketData.r, 0, params(5), params(2),...
                                  params(1), params(3), params(4));
            % Muunnetaan hinta implisiittiseksi volatiliteetiksi
            modelIV(i,j) = blsimpv(marketData.S0, marketData.K(j),...
                                  marketData.r, marketData.T(i), max(0, price));
        end
    end
    
    figure('Position', [100 100 1200 500]);
    subplot(1,2,1);
    surf(marketData.K, marketData.T, marketData.IV);
    title('Markkinavolaattisuora'); xlabel('Strike'); ylabel('T (vuosia)');
    
    subplot(1,2,2);
    surf(marketData.K, marketData.T, modelIV);
    title('Kalibroitu mallivolaattisuora'); 
    zlim([min(marketData.IV(:)) max(marketData.IV(:))]); 
end
% =========================================================================
function price = priceExoticOption(S0, r, params)
    % Hinnoittelee eksoottisen option (Down-and-in Asian Average Strike Call)
    % Monte Carlo -menetelmällä.
    % - Simuloi osakkeen ja varianssin polkuja Heston-mallin mukaisesti.
    % - Käyttää Milstein-skeemaa varianssiprosessin diskretoinnissa.
    % - Hyödyntää antiteettisia variansseja varianssin pienentämiseksi.
    % - Tarkistaa barrier-ehdon täyttymisen ja laskee option payoffin.
    
    % Alustetaan muuttujat
    nSteps = round(params.T/params.dt); % Askelten määrä per polku
    payoffs = zeros(params.M, 1); % Vektori simuloitujen polkujen payoffeille
    
    % Rinnakkaistettu silmukka Monte Carlo -simulaatioiden suorittamiseksi
    parfor i = 1:params.M
        % Generoidaan yksi normaali polku ja sille vastaava antiteettinen polku
        [S_path, S_anti] = simulateHestonPaths(S0, params, nSteps);
        
        % Lasketaan payoff kummallekin polulle
        payoff = calculatePayoff(S_path, params.H);
        payoff_anti = calculatePayoff(S_anti, params.H);
        
        % Keskiarvoistetaan normaalin ja anti polun payoffit
        payoffs(i) = 0.5*(payoff + payoff_anti);
    end
    
    % Diskontataan keskimääräinen payoff nykyhetkeen option hinnan saamiseksi
    price = exp(-r*params.T) * mean(payoffs);
end
% =========================================================================
function [S, S_anti] = simulateHestonPaths(S0, params, nSteps)
    % Simuloi Heston-mallin mukaisia osakkeen hinta- ja varianssipolkuja.
    % - Käyttää params-rakennetta Heston-mallin ja simulaation parametreille.
    % - Soveltaa Milstein-diskretointiskeemaa varianssiprosessille.
    
    % Alustetaan polut (normaali ja antiteettinen)
    V = params.V0 * ones(nSteps+1, 1); % Varianssipolku
    S = S0 * ones(nSteps+1, 1); % Osakkeen hintapolku
    V_anti = V; % Antiteettinen varianssipolku
    S_anti = S; % Antiteettinen osakkeen hintapolku
    
    % Satunnaisluvut
    Z1 = randn(nSteps, 1);
    e12 = randn(nSteps, 1);
    Z2 = params.rho * Z1 + sqrt(1 - params.rho^2) * e12;
    
    % Iteroidaan aikastepelien yli polkujen generoimiseksi
    for t = 1:nSteps
        % Päivitä varianssi (Milstein + truncation)
        sqrtV = sqrt(max(V(t), 0)); % Varmistetaan, ettei juurrettava ole negatiivinen
        % Varianssin päivitys: Drifti + Mean Reversion + Vol of Vol + Milstein-korjaus
        V(t+1) = max(0, V(t) + params.kappa * (params.theta - V(t)) * params.dt + ...
                    params.eta * sqrtV * sqrt(params.dt) * Z2(t) + ...
                    0.25 * params.eta^2 * params.dt * (Z2(t)^2 - 1));
        
        % Päivitä osakkeen hinta (Geometrinen Brownin liike paikallisella volatiliteetilla)
        S(t+1) = S(t) * exp((params.r - 0.5 * V(t)) * params.dt + ... % Driftitermi
                           sqrtV * sqrt(params.dt) * Z1(t)); % Volatiliteettitermi
        
        % Antiteettinen polku
        sqrtV_anti = sqrt(max(V_anti(t), 0));
        V_anti(t+1) = max(0, V_anti(t) + params.kappa * (params.theta - V_anti(t)) * params.dt + ...
                        params.eta * sqrtV_anti * sqrt(params.dt) * (-Z2(t)) + ...
                        0.25 * params.eta^2 * params.dt * (Z2(t)^2 - 1));
        
        % Päivitä antiteettinen osakkeen hinta
        S_anti(t+1) = S_anti(t) * exp((params.r - 0.5 * V_anti(t)) * params.dt + ...
                               sqrtV_anti * sqrt(params.dt) * (-Z1(t)));
    end
end
% =========================================================================
function payoff = calculatePayoff(S, H)
    % Laskee Down-and-in Asian Average Strike Call -option payoffin yhdelle simuloidulle polulle.
    % - Tarkistaa, onko barrier-ehto (S_t < H) täyttynyt milloin tahansa polun aikana.
    % - Laskee osakkeen hinnan aritmeettisen keskiarvon polun ajalta.
    
    barrierHit = any(S < H);
    avgPrice = mean(S);
    payoff = barrierHit * max(S(end) - avgPrice, 0);
end
% =========================================================================